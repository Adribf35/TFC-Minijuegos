<?php
class Database {
    private $host = "localhost";
    private $db_name = "tfc_minijuegos";
    private $username = "root";
    private $password = "";

    public function conectar() {
    try {
        $conexion = new PDO(
            "mysql:host={$this->host};dbname={$this->db_name};charset=utf8",
            $this->username,
            $this->password
        );

        $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $conexion;

    } catch (PDOException $e) {
        die(json_encode([
            "error" => "Error de conexión",
            "detalle" => $e->getMessage()
        ]));
    }
}
}