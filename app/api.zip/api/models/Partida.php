<?php
class Partida {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function guardarPartida($id_usuario, $id_juego, $fecha_partida, $puntuacion, $resultado) {

        $sql = "INSERT INTO partida 
                (id_usuario, id_juego, fecha_partida, puntuacion, resultado)
                VALUES (:id_usuario, :id_juego, :fecha_partida, :puntuacion, :resultado)";

        $stmt = $this->conn->prepare($sql);

        $stmt->bindParam(":id_usuario", $id_usuario);
        $stmt->bindParam(":id_juego", $id_juego);
        $stmt->bindParam(":fecha_partida", $fecha_partida);
        $stmt->bindParam(":puntuacion", $puntuacion);
        $stmt->bindParam(":resultado", $resultado);

        $stmt->execute();

        echo json_encode(["success" => true]);
    }
}