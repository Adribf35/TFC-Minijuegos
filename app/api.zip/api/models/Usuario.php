<?php
class Usuario {
    private $conexion;
    private $tabla = "usuario";

    public function  __construct($db) {
        $this->conexion = $db;
    }

    public function obtenerPorLogin($login) {
    $sql = "SELECT * FROM usuario 
            WHERE LOWER(email) = LOWER(:login)
            OR LOWER(nombre_usuario) = LOWER(:login)";

    $consulta = $this->conexion->prepare($sql);
    $consulta->bindParam(":login", $login);
    $consulta->execute();

    return $consulta->fetch(PDO::FETCH_ASSOC);
}
      public function registrar($nombre, $email, $password_hash) {
        $sql = "INSERT INTO " . $this->tabla . " 
                (nombre_usuario, email, password_hash, fecha_registro) 
                VALUES (:nombre, :email, :password, NOW())";

        $consulta = $this->conexion->prepare($sql);

        $consulta->bindParam(":nombre", $nombre);
        $consulta->bindParam(":email", $email);
        $consulta->bindParam(":password", $password_hash);

        return $consulta->execute();
    }
    public function existeUsuario($nombre, $email) {
    $sql = "SELECT * FROM usuario 
            WHERE nombre_usuario = :nombre OR email = :email";
    
    $consulta = $this->conexion->prepare($sql);
    $consulta->bindParam(":nombre", $nombre);
    $consulta->bindParam(":email", $email);
    $consulta->execute();

    return $consulta->fetch(PDO::FETCH_ASSOC);
}
}