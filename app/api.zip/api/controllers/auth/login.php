<?php
header("Content-Type: application/json");

require_once __DIR__ . "/../../config/database.php";
require_once "../../models/Usuario.php";
$data = json_decode(file_get_contents("php://input"), true);

$login = trim($data["login"] ?? "");
$password = $data["password"] ?? "";

$db = new Database();
$conexion = $db->conectar();

$usuarioModel = new Usuario($conexion);
$usuario = $usuarioModel->obtenerPorLogin($login);

if ($usuario && password_verify($password, $usuario["password_hash"])) {
    echo json_encode([
        "status" => "ok",
        "usuario" => [
            "id" => $usuario["id_usuario"],
            "nombre" => $usuario["nombre_usuario"]
        ]
    ]);

} else {
    echo json_encode([
        "status" => "error",
        "mensaje" => "Credenciales incorrectas"
    ]);
}