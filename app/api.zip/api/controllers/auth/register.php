<?php
header("Content-Type: application/json");

require_once __DIR__ . "/../../config/database.php";
require_once "../../models/Usuario.php";
$db = new Database();
$conexion = $db->conectar();

$usuarioModel = new Usuario($conexion);
$data = json_decode(file_get_contents("php://input"), true);

$nombre = $data["nombre"] ?? "";
$email = $data["email"] ?? "";
$password = $data["password"] ?? "";

// Validaciones
if (empty($nombre) || empty($email) || empty($password)) {
    echo json_encode([
        "status" => "error",
        "mensaje" => "Todos los campos son obligatorios"
    ]);
    exit;
}




//Verificar si ya existe
$existe = $usuarioModel->existeUsuario($nombre,$email);

if ($existe) {
    echo json_encode([
        "status" => "error",
        "mensaje" => "El usuario o email ya existe"
    ]);
    exit;
}

//Encriptar contraseña
$password_hash = password_hash($password, PASSWORD_DEFAULT);

//Registrar usuario
$registro = $usuarioModel->registrar($nombre, $email, $password_hash);

if ($registro) {
    echo json_encode([
        "status" => "ok",
        "mensaje" => "Usuario registrado correctamente"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "mensaje" => "Error al registrar usuario"
    ]);
}
