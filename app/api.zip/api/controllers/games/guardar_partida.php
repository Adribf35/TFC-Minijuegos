<?php

header("Content-Type: application/json");

require_once __DIR__ . "/../../config/database.php";
require_once __DIR__ . "/../../models/Partida.php";

$data = json_decode(file_get_contents("php://input"), true);

if (
    !isset($data["id_usuario"]) ||
    !isset($data["id_juego"]) ||
    !isset($data["puntuacion"]) ||
    !isset($data["resultado"]) ||
    !isset($data["fecha_partida"])
) {
    echo json_encode([
        "success" => false,
        "message" => "Faltan datos"
    ]);
    exit;
}

$db = new Database();
$conn = $db->conectar();

$partida = new Partida($conn);

$resultado = $partida->guardarPartida(
    $data["id_usuario"],
    $data["id_juego"],
    $data["fecha_partida"],
    $data["puntuacion"],
    $data["resultado"]
);

echo json_encode($resultado);